package com.varsitycollege.kotlincalcultorp3
//Muhammed-Safwaan-Ally-ST10352114
//Varsity College Durban North
//There are no changes made from part 2 to 3
//https://www.loom.com/share/8cc108436a3e4c77a6ae9989ec5911c4?sid=5ec947a7-603c-4a3f-beb0-2352602046a7


//REFERENCE:
//www.youtube.com. (n.d.). Simple Calculator Using Kotlin. [online] Available at: https://youtu.be/Zi1XgFTUH9k?si=Ar-_XKP4OgvcI4KX [Accessed 18 Sep. 2023].


import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val openStatisticsButton = findViewById<Button>(R.id.buttonOpenStatistics)
        openStatisticsButton.setOnClickListener{
            val intent = Intent(this, StatisticsActivity::class.java)
            startActivity(intent)
        }




        //setting our variables and view by ids
//creating our calculator buttons and assigning them

        val number1 = findViewById<EditText>(R.id.Number1)
        val number2 = findViewById<EditText>(R.id.Number2)
        val answerTextView = findViewById<TextView>(R.id.Answer)
        val multiplicationButton = findViewById<Button>(R.id.Multiplication)
        val divisionButton = findViewById<Button>(R.id.Division)
        val subtractionButton = findViewById<Button>(R.id.Subtraction)
        val additionButton = findViewById<Button>(R.id.Addition)
        val squareRootButton = findViewById<Button>(R.id.SquareRoot)
        val powerButton = findViewById<Button>(R.id.Power)
        val statsButton = findViewById<Button>(R.id.buttonOpenStatistics)


        //setting on click listeners for each of our calculator buttons
        multiplicationButton.setOnClickListener {

            //use the toInt() to convert to an integer and allows for return
            val multiplynumber1 = number1.text.toString().toInt()
            val multiplynumber2 = number2.text.toString().toInt()

            val answer = multiplynumber1 * multiplynumber2
            //use the $ to get the exact value of the answer and the 2 numbers
            answerTextView.text = "$multiplynumber1 * $multiplynumber2 = $answer"
        }

        divisionButton.setOnClickListener {
//this is the divison button
            val dividenumber1 = number1.text.toString().toInt()
            val dividenumber2 = number2.text.toString().toInt()
//In part 2 I have added the error message to display when you try to divide by 0
            if (dividenumber2 == 0) {
                answerTextView.text = "Error: Division by zero is not allowed."
            } else {
                val answer = dividenumber1.toDouble() / dividenumber2.toDouble()
                answerTextView.text = "$dividenumber1 / $dividenumber2 = $answer"
            }

        }

        subtractionButton.setOnClickListener {

            val minusnumber1 = number1.text.toString().toInt()
            val minusnumber2 = number2.text.toString().toInt()

            val answer = minusnumber1 - minusnumber2
            answerTextView.text = "$minusnumber1 - $minusnumber2 = $answer"
        }

        additionButton.setOnClickListener {

            val addnumber1 = number1.text.toString().toInt()
            val addnumber2 = number2.text.toString().toInt()

            val answer = addnumber1 + addnumber2
            answerTextView.text = "$addnumber1 + $addnumber2 = $answer"
        }

        squareRootButton.setOnClickListener {
//this function is new to my calculator app
            val inputNumber = number1.text.toString().toDouble()
//the correct display of the answer has been added here as according to the POE
//I have used else if statements to ensure a smooth run of operations, keeping it short and sweet
            if (inputNumber >= 0) {
                val squareRoot = sqrt(inputNumber)
                answerTextView.text = "sqrt($inputNumber) = $squareRoot"
            } else {
                val absValue = kotlin.math.abs(inputNumber)
                val imaginarySquareRoot = sqrt(absValue)
                //I have added i for imaginary number, id the 1st number is negative
                //meaning below 0
                answerTextView.text = "sqrt($inputNumber) = ${imaginarySquareRoot}i"
            }

        }

        powerButton.setOnClickListener {

            val base = number1.text.toString().toDouble()
            val exponent = number2.text.toString().toInt()

            var result = 1.0
//the correct display of the answer has been added here as according to the POE requirements for Part 2
            if (exponent >= 0) {
                for (i in 1..exponent) {
                    result *= base
                }
                answerTextView.text = "$base^$exponent = $result"
            } else {
                answerTextView.text = "Error: Negative exponent is not allowed."
            }
        }

    }
}
