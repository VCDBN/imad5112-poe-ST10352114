package com.varsitycollege.kotlincalcultorp3
//Muhammed-Safwaan-Ally-ST10352114
//Varsity College Durban North
//There are no changes made from part 2 to 3
//https://www.loom.com/share/8cc108436a3e4c77a6ae9989ec5911c4?sid=5ec947a7-603c-4a3f-beb0-2352602046a7


//REFERENCE:
//www.youtube.com. (n.d.). Simple Calculator Using Kotlin. [online] Available at: https://youtu.be/Zi1XgFTUH9k?si=Ar-_XKP4OgvcI4KX [Accessed 18 Sep. 2023].


import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class StatisticsActivity : AppCompatActivity() {

    // Declare variables
    lateinit var InputNumber: EditText
    lateinit var NumbersStored: TextView

    // Create a variable to store the array, set the array to 0
    var arr: ArrayList<Int> = ArrayList(0)

    //initialize ur buttons and textViews
    lateinit var minButton: Button
    lateinit var maxButton: Button
    lateinit var minTextView: TextView
    lateinit var maxTextView: TextView
    lateinit var AverageTV: TextView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_statistics)

        InputNumber = findViewById(R.id.NumberInput)
        NumbersStored = findViewById(R.id.StoredNumbersTV)

        // Declare and initialize the 2 buttons
        val additionButton = findViewById<Button>(R.id.Addbtn)
        val clearButton = findViewById<Button>(R.id.Clearbtn)
        val averageButton = findViewById<Button>(R.id.Averagebtn)

        // Initialize the minimum and maximum buttons and TextViews
        minButton = findViewById(R.id.Minbtn)
        maxButton = findViewById(R.id.Maxbtn)
        minTextView = findViewById(R.id.MinTV)
        maxTextView = findViewById(R.id.MaxTV)
        AverageTV = findViewById(R.id.AverageTV)

        additionButton.setOnClickListener {
            // Create a variable to store/hold the numbers entered in the input field
            val num1 = InputNumber.text.toString()

            // ive chosen to use else if statements
            if (num1.isBlank()) {
                Toast.makeText(this, "Oops! Please enter a Number", Toast.LENGTH_SHORT).show()
            } else if (arr.size != 11) {
                additionButton(num1.toInt())
                InputNumber.text.clear()
            } else if (arr.size == 11) {
                Toast.makeText(this, "Maximum Number Reached", Toast.LENGTH_SHORT).show()
            }
        }

        clearButton.setOnClickListener {
            if (arr.size == 11) {
                Toast.makeText(this, "Please fill the array", Toast.LENGTH_SHORT).show()
            } else {
                arr.clear()
                InputNumber.text.clear()
                NumbersStored.text = ""
            }
        }

        minButton.setOnClickListener {
            calculateMinMax(minTextView, maxTextView)
        }

        maxButton.setOnClickListener {
            calculateMinMax(minTextView, maxTextView)
        }

        averageButton.setOnClickListener {
            calculateAverage(AverageTV)
        }
    }

    private fun additionButton(num1: Int) {
        arr.add(num1)

        val str = StringBuilder()
        for (x in arr) {
            str.append(x).append(", ")
        }

        NumbersStored.text = str.toString().trimEnd(',', ' ')
    }
//max and min calculation done here
    private fun calculateMinMax(minTextView: TextView, maxTextView: TextView) {
        if (arr.isEmpty()) {
            minTextView.text = "No numbers to calculate the minimum."
            maxTextView.text = "No numbers to calculate the maximum."
        } else {
            val min = arr.minOrNull()
            val max = arr.maxOrNull()
            minTextView.text = "Minimum: $min"
            maxTextView.text = "Maximum: $max"
        }
    }


//here is my calculation for the average button
    private fun calculateAverage(AverageTV: TextView) {
        if (arr.isEmpty()) {
            AverageTV.text = "No numbers to calculate the average."
        } else {
            val sum = arr.sum()
            val average = sum.toDouble() / arr.size
            val averageString = String.format("%.2f", average)
            AverageTV.text = "Average: $averageString"
        }
    }
}
